/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package matchmaking;

import java.sql.*;
import static matchmaking.Retrieval.cdb;
//import java.sql.DriverManager;
//import java.sql.SQLException;
//import java.sql.Statement;

/**
 *
 * @author Habibur Rahman
 */
public class MatchMaking {

    /**
     * @param args the command line arguments
     */
   /* Connection conn = null;
        PreparedStatement myStmt = null;
        public static Connection ConnectDB(){
            
        }*/
    public static void main(String[] args) throws SQLException {
        //Retrieval r=new Retrieval();
        cdb();
        // TODO code application logic here
        //.String url = "jdbc:mysql://localhost:3306/MatchmakingDB";
        //String user = "root";
        //String password = "";
        
        
        /*
        ResultSet myRs = null;
        try {
            String Name="Mayeesha",Gender="Female",Email="mayeeshahumaira@gmail.com";
// 1. Get a connection to database
            myConn = DriverManager.getConnection("jdbc:mysql://localhost:3306/MatchmakingDB", "root", "");
// 2. Create a statement
            myStmt = myConn.createStatement();
// 3. Execute SQL query
            String sql = "insert into matchmaking " + " (Name,Gender,Email)"
                    + " values (Name,Gender,Email)";
            myRs = myStmt.executeQuery("select * from matchmaking");
            while (myRs.next()) {
				System.out.println(myRs.getString("Name") + ", " + myRs.getString("Phone"));
			}
            myStmt.executeUpdate(sql);
            System.out.println("Update executed");
            System.out.println("Insert complete.");
        } catch (Exception exc) {
            exc.printStackTrace();
        } finally {
            if (myStmt != null) {
                myStmt.close();
            }
            if (myConn != null) {
                myConn.close();
            }
        }*/
        /*Statement sta = null;
        Connection con = null;
        try{
            String host="jdbc:derby://localhost:1527/MyDataBase" ;
            String uName="SD";
            String uPass="1234";
            con=DriverManager.getConnection(host, uName, uPass);
            sta=con.createStatement();
            String name="Torunima", email="tt@gmail.com", phone="012345", dob="14/08/1997", gender="female",
                    religion="agnostic", occu="student", edu="A levels", height="5 ft 2 in", build="plump",
                    mari="unmarried", area="Dhaka", preligion="agnostic", poccu="student", pedu="a levels", 
                     pbuild="athletic", pmari="unmarried", parea="dhaka", 
                    personality="ambivert", hobbies="crafting", charac="lazy,liberal", 
        about="lalalalalalalaaaaa",password="poopypants",heightStart="62",heightEnd="72",ageStart="20",ageEnd="40";
            
            int c=sta.executeUpdate("INSERT INTO Table1"+"(Name,Gender,Email,PhoneNumber,Religion,Occupation,Education,Height,PhysicalBuilt,MartialStatus,Area,Partner_Religion,Partner_Occupation,Partner_Education,Partner_Height,Partner_PhysicalBuilt,Partner_MartialStatus,Partner_Area,Personality,Hobby,Charecteristics,DateOfBirth,About)"+
                    "VALUES(name,gender,email,phone,religion,occu,edu,height,build,mari,area,preligion,poccu,pedu,pheight,pbuild,pmari,parea,personality,hobbies,charac,dob,about)");
            
        }catch(SQLException err){
            System.out.println(err.getMessage());
        }finally{
            sta.close();
            con.close();
            
        }*/
 /*Connection myConn = null;
        Statement myStmt = null;
        ResultSet myRs = null;

        try {
            // 1. Get a connection to database
            myConn = DriverManager.getConnection("jdbc:mysql://localhost:3306/MatchmakingDB", "root", "");

            // 2. Create a statement
            myStmt = myConn.createStatement();
            String name = "Torunima", email = "tt@gmail.com", phone = "012345", dob = "14/08/1997", gender = "female",
                    religion = "agnostic", occu = "student", edu = "A levels", height = "5 ft 2 in", build = "plump",
                    mari = "unmarried", area = "Dhaka", preligion = "agnostic", poccu = "student", pedu = "a levels",
                    pbuild = "athletic", pmari = "unmarried", parea = "dhaka",
                    personality = "ambivert", hobbies = "crafting", charac = "lazy,liberal",
                    about = "lalalalalalalaaaaa", password = "poopypants", heightStart = "62", heightEnd = "72", ageStart = "20", ageEnd = "40";

            // 3. Execute SQL query
            //myRs = myStmt.executeQuery("select * from matchmaking");
            // 4. Process the result set
            /*while (myRs.next()) {
				System.out.println(myRs.getString("Name") + ", " + myRs.getString("Phone"));
			}*/
 /*String sql = "insert into matchmaking " + " (Name,Gender,Email,Password,Phone,Religion,Occupation,Education,Height,Build,Marital Status,Area,Partner Rel,Partner Occu,Partner Edu,Partner Height Start,Partner Height End,Partner Build,Partner Age Start,Partner Age End,Partner Mari,Partner Area,Personality,Hobbies,Charecteristics,DOB,About)"
                    + " values (name,gender,email,password,phone,religion,occu,edu,height,build,mari,area,preligion,poccu,pedu,heightStart,heightEnd,pbuild,ageStart,ageEnd,pmari,parea,personality,hobbies,charac,dob,about)";
            myStmt.executeUpdate(sql);
            System.out.println("Insert complete.");
        } catch (Exception exc) {
            exc.printStackTrace();
        } finally {
            if (myRs != null) {
                myRs.close();
            }

            if (myStmt != null) {
                myStmt.close();
            }

            if (myConn != null) {
                myConn.close();
            }
        }*/
    }

}
