/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package matchmaking;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author Habibur Rahman
 */
public class Retrieval {

    //public static void main(String[] args) {
    static Connection c = null;
    static Statement myStmt = null, myStmt1 = null, myStmt2 = null, myStmt3 = null, myStmt4 = null;
    static ResultSet myRsw = null, myRs1 = null, myRs2 = null, myRs3 = null, myRs4 = null;
    public static ArrayList<Welcome> welcomeList = new ArrayList<>();
    public static ArrayList<Q1> q1List = new ArrayList<>();
    public static ArrayList<Q2> q2List = new ArrayList<>();
    public static ArrayList<Q3> q3List = new ArrayList<>();
    public static ArrayList<Female> flist = new ArrayList<>();
    public static ArrayList<Male> mlist = new ArrayList<>();
    //static ArrayList<Q4> q4List = new ArrayList<>();

    public static Connection cdb() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection cw = DriverManager.getConnection("jdbc:mysql://localhost:3306/mmwdb?useSSL=false", "root", "");
            Connection c1 = DriverManager.getConnection("jdbc:mysql://localhost:3306/mm1db?useSSL=false", "root", "");
            Connection c2 = DriverManager.getConnection("jdbc:mysql://localhost:3306/mm2db?useSSL=false", "root", "");
            Connection c3 = DriverManager.getConnection("jdbc:mysql://localhost:3306/mm3db?useSSL=false", "root", "");
            Connection c4 = DriverManager.getConnection("jdbc:mysql://localhost:3306/mm4db?useSSL=false", "root", "");
            myStmt = cw.createStatement();
            myStmt1 = c1.createStatement();
            myStmt2 = c2.createStatement();
            myStmt3 = c3.createStatement();
            myStmt4 = c4.createStatement();

            int i = 0, j = 0;
            Welcome w;
            Q1 q1;
            Q2 q2;
            Q3 q3;
            Female f;
            Male m;
            //Q4 q4;
            /*myRsw = myStmt.executeQuery("select * from mmw");
            while (myRsw.next()) {
                w = new Welcome(myRsw.getInt("ID"), myRsw.getString("Name"), myRsw.getString("Email"),
                        myRsw.getString("Phone"), myRsw.getString("DOB"), myRsw.getString("Gender"));
                welcomeList.add(w);
            }
            myRs1 = myStmt1.executeQuery("select * from mm1");
            while (myRs1.next()) {
                q1 = new Q1(myRsw.getInt("ID"), myRs1.getString("Rel"), myRs1.getString("Occu"), myRs1.getString("Edu"), myRs1.getInt("Height"), myRs1.getString("Phy_Build"), myRs1.getString("Mari_Status"), myRs1.getString("Area"));
                q1List.add(q1);
                //System.out.println(myRs1.getString("Rel"));
            }
            while (myRs1.next()) {
                System.out.println(myRs1.getString("Rel"));
            }
            myRs2 = myStmt2.executeQuery("select * from mm2");
            while (myRs2.next()) {
                q2 = new Q2(myRsw.getInt("ID"), myRs2.getString("P_Rel"), myRs2.getString("P_Occu"), myRs2.getString("P_Edu"), myRs2.getInt("Height_S"), myRs2.getInt("Height_E"), myRs2.getInt("Age_S"), myRs2.getInt("Age_E"), myRs2.getString("P_Phy_Build"), myRs2.getString("PMari"), myRs2.getString("PArea"));
                q2List.add(q2);
            }
            myRs3 = myStmt3.executeQuery("select * from mm3");
            while (myRs3.next()) {
                q3 = new Q3(myRsw.getInt("ID"), myRs3.getString("Personality"), myRs3.getString("Hobbies"), myRs3.getString("Charac"));
                q3List.add(q3);
            }*/
            String gender = "Female";
            myRsw = myStmt.executeQuery("select * from alldata");
            //if(gender.equals(myRsw.getString("Gender")))
            while (myRsw.next()) {
                if(gender.equals(myRsw.getString("Gender"))){
                f = new Female(myRsw.getInt("ID"), myRsw.getString("Name"), myRsw.getString("Email"),
                        myRsw.getString("Phone"), myRsw.getString("DOB"), myRsw.getString("Gender"),
                        myRsw.getString("Rel"), myRsw.getString("Occu"), myRsw.getString("Edu"), myRsw.getInt("Height"),
                        myRsw.getString("Phy_Build"), myRsw.getString("Mari_Status"), myRsw.getString("Area"),
                        myRsw.getString("P_Rel"), myRsw.getString("P_Occu"), myRsw.getString("P_Edu"), myRsw.getInt("Height_S"), myRs2.getInt("Height_E"), myRs2.getInt("Age_S"), myRs2.getInt("Age_E"),
                        myRsw.getString("P_Phy_Build"), myRsw.getString("PMari"), myRsw.getString("PArea"),
                myRsw.getString("Personality"), myRsw.getString("Hobbies"), myRsw.getString("Charac"));
                flist.add(f);
                }else{
                    //while (myRsw.next()) {
                m = new Male(myRsw.getInt("ID"), myRsw.getString("Name"), myRsw.getString("Email"),
                        myRsw.getString("Phone"), myRsw.getString("DOB"), myRsw.getString("Gender"),
                        myRsw.getString("Rel"), myRsw.getString("Occu"), myRsw.getString("Edu"), myRsw.getInt("Height"),
                        myRsw.getString("Phy_Build"), myRsw.getString("Mari_Status"), myRsw.getString("Area"),
                        myRsw.getString("P_Rel"), myRsw.getString("P_Occu"), myRsw.getString("P_Edu"), myRsw.getInt("Height_S"), myRs2.getInt("Height_E"), myRs2.getInt("Age_S"), myRs2.getInt("Age_E"),
                        myRsw.getString("P_Phy_Build"), myRsw.getString("PMari"), myRsw.getString("PArea"),
                myRsw.getString("Personality"), myRsw.getString("Hobbies"), myRsw.getString("Charac"));
                mlist.add(m);
                    
                }
               
            }
           /* myRsw = myStmt.executeQuery("select * from alldata");
            while (myRsw.next()) {
                m = new Male(myRsw.getInt("ID"), myRsw.getString("Name"), myRsw.getString("Email"),
                        myRsw.getString("Phone"), myRsw.getString("DOB"), myRsw.getString("Gender"),
                        myRsw.getString("Rel"), myRsw.getString("Occu"), myRsw.getString("Edu"), myRsw.getInt("Height"),
                        myRsw.getString("Phy_Build"), myRsw.getString("Mari_Status"), myRsw.getString("Area"),
                        myRsw.getString("P_Rel"), myRsw.getString("P_Occu"), myRsw.getString("P_Edu"), myRsw.getInt("Height_S"), myRs2.getInt("Height_E"), myRs2.getInt("Age_S"), myRs2.getInt("Age_E"),
                        myRsw.getString("P_Phy_Build"), myRsw.getString("PMari"), myRsw.getString("PArea"),
                myRsw.getString("Personality"), myRsw.getString("Hobbies"), myRsw.getString("Charac"));
                mlist.add(m);
                 
            }*/


            /*myRs4 = myStmt4.executeQuery("select * from mm4");
            while (myRs4.next()) {
                q4 = new Q4(myRs4.getString("About"));
                q4List.add(q4);
            }*/
 /*for (int m = 0; m < q1List.size(); m++) {
                System.out.println(q1List.get(m).area);

            }*/
 /*System.out.println("sssssh");
            for (int m = 0; m < welcomeList.size(); m++) {
                System.out.println(welcomeList.get(m).dob);

            }*/
 /*
            for (int m = 0; m < q2List.size(); m++) {
                System.out.println(q2List.get(m).pmari);

            }
            for (int m = 0; m < q3List.size(); m++) {
                System.out.println(q3List.get(m).charac);

            }*/
            return cw;
        } catch (Exception e) {
            System.out.println(e);
            return null;
        }

    }

    void Algorithm() {

    }
}
