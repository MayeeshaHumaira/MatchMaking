/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package matchmaking;

/**
 *
 * @author Habibur Rahman
 */
public class AllTheClasses {
    Welcome w;
    Q1 q1;
    Q2 q2;
    Q3 q3;
    //Q4 q4;
    AllTheClasses(Welcome w,Q1 q1,Q2 q2,Q3 q3){
        this.w=w;
        this.q1=q1;
        this.q2=q2;
        this.q3=q3;
        //this.q4=q4;
    }
}
class Welcome{
    String name, email, phone, dob, gender;
    int id;
    Welcome(int id,String name, String email, String phone, String dob, String gender){
        this.id=id;
        this.name=name;
        this.email=email; 
        this.phone=phone; 
        this.dob=dob; 
        this.gender=gender;
        
    }
}
class Q1{
    String religion, occu, edu,  build, mari, area;
    int height;
    int id;
    Q1(int id,String religion,String occu, String edu, int height, String build, String mari, String area){
        this.id=id;
        this.religion=religion; 
        this.occu=occu; 
        this.edu=edu; 
        this.height=height; 
        this.build=build; 
        this.mari=mari; 
        this.area=area; 
        
    }
}
class Q2{
    String preligion, poccu, pedu,  pbuild, pmari, parea;
    int pheightstart,pheightend,pagestart,pageend;
    int id;
    Q2(int id,String preligion, String poccu, String pedu, int pheightstart,int pheightend,
            int pagestart, int pageend, String pbuild, String pmari, String parea){
        this.id=id;
        this.preligion=preligion; 
        this.poccu=poccu;
        this.pedu=pedu; 
        this.pheightstart=pheightstart;
        this.pheightend=pheightend;
        this.pagestart=pagestart;
        this.pageend=pageend;
        this.pbuild=pbuild; 
        this.pmari=pmari; 
        this.parea=parea;
        
    }
}
class Q3{
    String personality, hobbies, charac;
    int id;
    Q3(int id,String personality, String hobbies, String charac){
        this.id=id;
        this.personality=personality; 
        this.hobbies=hobbies; 
        this.charac=charac; 
        
    }
}
class Q4{
    String about;
    Q4(String about){
        this.about=about;
    }
}
class Female{
    String name, email, phone, dob, gender,
            religion, occu, edu,  build, mari, area,
            preligion, poccu, pedu,  pbuild, pmari, parea,personality, hobbies, charac;
    int height,id, pheightstart,pheightend,pagestart,pageend;
    Female(int id,String name, String email, String phone, String dob,
            String gender,String religion,String occu, String edu, int height,
            String build, String mari, String area,String preligion, String poccu, String pedu, int pheightstart,int pheightend,
            int pagestart, int pageend, String pbuild, 
            String pmari, String parea,String personality, String hobbies, String charac){
        this.id=id;
        this.name=name;
        this.email=email; 
        this.phone=phone; 
        this.dob=dob; 
        this.gender=gender;
        this.religion=religion; 
        this.occu=occu; 
        this.edu=edu; 
        this.height=height; 
        this.build=build; 
        this.mari=mari; 
        this.area=area; 
        this.preligion=preligion; 
        this.poccu=poccu;
        this.pedu=pedu; 
        this.pheightstart=pheightstart;
        this.pheightend=pheightend;
        this.pagestart=pagestart;
        this.pageend=pageend;
        this.pbuild=pbuild; 
        this.pmari=pmari; 
        this.parea=parea;
        this.personality=personality; 
        this.hobbies=hobbies; 
        this.charac=charac; 
        
        
    
}
}
class Male{
    String name, email, phone, dob, gender,
            religion, occu, edu,  build, mari, area,
            preligion, poccu, pedu,  pbuild, pmari, parea,personality, hobbies, charac;
    int height,id, pheightstart,pheightend,pagestart,pageend;
    Male(int id,String name, String email, String phone, String dob,
            String gender,String religion,String occu, String edu, int height,
            String build, String mari, String area,String preligion, String poccu, String pedu, int pheightstart,int pheightend,
            int pagestart, int pageend, String pbuild, 
            String pmari, String parea,String personality, String hobbies, String charac){
        this.id=id;
        this.name=name;
        this.email=email; 
        this.phone=phone; 
        this.dob=dob; 
        this.gender=gender;
        this.religion=religion; 
        this.occu=occu; 
        this.edu=edu; 
        this.height=height; 
        this.build=build; 
        this.mari=mari; 
        this.area=area; 
        this.preligion=preligion; 
        this.poccu=poccu;
        this.pedu=pedu; 
        this.pheightstart=pheightstart;
        this.pheightend=pheightend;
        this.pagestart=pagestart;
        this.pageend=pageend;
        this.pbuild=pbuild; 
        this.pmari=pmari; 
        this.parea=parea;
        this.personality=personality; 
        this.hobbies=hobbies; 
        this.charac=charac; 
        
        
    
}
}

