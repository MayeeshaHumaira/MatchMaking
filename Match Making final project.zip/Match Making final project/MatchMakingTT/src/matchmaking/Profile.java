/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package matchmaking;

import java.awt.Image;
import java.io.File;
import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.ImageIcon;
import static matchmaking.Retrieval.myRs1;
import static matchmaking.Retrieval.myRs2;
import static matchmaking.Retrieval.myRs3;
import static matchmaking.Retrieval.myRsw;
import static matchmaking.Retrieval.myStmt;
import static matchmaking.Retrieval.myStmt1;
import static matchmaking.Retrieval.myStmt3;
import static matchmaking.Retrieval.myStmt2;
import static matchmaking.LoginPage.id;
import static matchmaking.Matches.showMatchID;
import static matchmaking.Quiz3.currentID;
import static matchmaking.Retrieval.welcomeList;
import static matchmaking.Retrieval.flist;
import static matchmaking.Retrieval.mlist;
//import static matchmaking.Retrieval.myRsw;
//import static matchmaking.Retrieval.myStmt1;

/**
 *
 * @author Habibur Rahman
 */
public class Profile extends javax.swing.JFrame {

    /**
     * Creates new form Profile
     */
    String currentName, currentGender, currentDOB, currentEmail, currentPhone,
            currentRel, currentOccu, currentEdu, currentBuild, currentMari, currentArea,
            prefRel, prefOccu, prefEdu, prefBuild, prefMari, prefArea, currentPersonality,
            currentHobbies, currentCharac;

    int currentAge, prefHeightStart, prefHeightEnd, prefAgeStart, prefAgeEnd, currentHeight;
    
            
    public static int matchID[]=new int[100];
    public static int matchFound = 0;
    byte[] currentImage;
    PreparedStatement pst = null;

    public Profile(int idp) {
        initComponents();
        //jLabel1.setName("HIIIII");
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Statement myStmt = null;
            ResultSet myRsw = null;
            Connection cw = DriverManager.getConnection("jdbc:mysql://localhost:3306/mmwdb?useSSL=false", "root", "");
            myStmt = cw.createStatement();

            myRsw = myStmt.executeQuery("select * from mmw");
            System.out.println("Entering loop...");
            while (myRsw.next()) {
                if (myRsw.getInt("ID") == idp ) {
                    jLabel2.setText(myRsw.getString("Name"));
                    jLabel8.setText(myRsw.getString("DOB"));
                    jLabel5.setText(myRsw.getString("Email"));
                    jLabel6.setText(myRsw.getString("Phone"));
                    byte[] img = myRsw.getBytes("Photo");
                    ImageIcon image = new ImageIcon(img);
                    Image im = image.getImage();
                    Image myImg = im.getScaledInstance(jLabel1.getWidth(), jLabel1.getHeight(), Image.SCALE_SMOOTH);
                    ImageIcon newImage = new ImageIcon(myImg);
                    jLabel1.setIcon(newImage);
                }
            }
            Connection c3 = DriverManager.getConnection("jdbc:mysql://localhost:3306/mm3db?useSSL=false", "root", "");
            Statement myStmt3 = c3.createStatement();
            ResultSet myRs3 = null;
            myRs3 = myStmt3.executeQuery("select * from mm3");
            while (myRs3.next()) {
                if (myRs3.getInt("ID") == id || myRs3.getInt("ID") == currentID) {
                    jLabel10.setText(myRs3.getString("Hobbies"));
                    //System.out.println(myRs3.getString("Charac"));
                    jLabel13.setText(myRs3.getString("Charac") + "\n" + myRs3.getString("Personality"));

                }
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        //THIS ONE HERE
        /*
        try {

            //Connection cn = dbConnection.cdb();
            //File file = new File(filename.getAbsolutePath());
            //fis = new FileInputStream(file);
            Class.forName("com.mysql.jdbc.Driver");
            Connection c = DriverManager.getConnection("jdbc:mysql://localhost:3306/mmwdb?useSSL=false", "root", "");
            ResultSet myRsw = null;

            Statement myStmt = c.createStatement();

            myRsw = myStmt.executeQuery("select * from mmw");
            //if(gender.equals(myRsw.getString("Gender")))
            while (myRsw.next()) {

                currentName = myRsw.getString("Name");
                currentGender = myRsw.getString("Gender");
                 currentEmail = myRsw.getString("Email");
                currentDOB = myRsw.getString("DOB");
               
                currentPhone = myRsw.getString("Phone");
                currentImage = myRsw.getBytes("Photo");
                currentAge = myRs1.getInt("Age");

            }
            Connection c1 = DriverManager.getConnection("jdbc:mysql://localhost:3306/mm1db?useSSL=false", "root", "");
            ResultSet myRs1 = null;
            Statement myStmt1 = c1.createStatement();
            myRs1 = myStmt1.executeQuery("select * from mm1");
            while (myRs1.next()) {
                
                currentRel = myRs1.getString("Rel");
                currentOccu = myRs1.getString("Occu");
                currentEdu = myRs1.getString("Edu");
                currentHeight = myRs1.getInt("Height");
                currentBuild = myRs1.getString("Phy_Build");
                currentMari = myRs1.getString("Mari_Status");
                currentArea = myRs1.getString("Area");

            }
            // ResultSet myRs2 = myStmt.executeQuery("select * from mmw");
            Connection c2 = DriverManager.getConnection("jdbc:mysql://localhost:3306/mm2db?useSSL=false", "root", "");
            ResultSet myRs2 = null;
            Statement myStmt2 = c2.createStatement();

            myRs2 = myStmt2.executeQuery("select * from mm2");
            while (myRs2.next()) {
                prefRel = myRs2.getString("P_Rel");
                prefOccu = myRs2.getString("P_Occu");
                prefEdu = myRs2.getString("P_Edu");
                prefHeightStart = myRs2.getInt("Height_S");
                prefHeightEnd = myRs2.getInt("Height_E");
                prefBuild = myRs2.getString("P_Phy_Build");
                prefMari = myRs2.getString("PMari");
                prefArea = myRs2.getString("PArea");
                prefAgeStart = myRs2.getInt("Age_S");
                prefAgeEnd = myRs2.getInt("Age_E");

            }
            Connection c3 = DriverManager.getConnection("jdbc:mysql://localhost:3306/mm3db?useSSL=false", "root", "");
            ResultSet myRs3 = null;
            Statement myStmt3 = c3.createStatement();

            myRs3 = myStmt3.executeQuery("select * from mm3");
            while (myRs3.next()) {
                currentPersonality = myRs3.getString("Personality");
                currentHobbies = myRs3.getString("Hobbies");
                currentCharac = myRs3.getString("Charac");
            }
        } catch (Exception e) {
            System.out.println("error");
            System.out.println(e);
        }

        try {

            Connection cn = dbConnection.cdb();

            String Query = "INSERT INTO alldata values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
            pst = cn.prepareStatement(Query);
            pst.setInt(1, currentID);
            //id++;
            pst.setString(2, currentName);
            pst.setString(3, currentGender);
            pst.setString(4, currentEmail);
            pst.setString(5, currentDOB);
            pst.setString(6, currentPhone);
            pst.setBytes(7, currentImage);
            pst.setInt(8, currentAge);
            pst.setString(9, currentRel);
            pst.setString(10, currentOccu);s
            pst.setString(11, currentEdu);
            pst.setInt(12, currentHeight);
            pst.setString(13, currentBuild);
            pst.setString(14, currentMari);
            pst.setString(15, currentArea);
            pst.setString(16, prefRel);
            pst.setString(17, prefOccu);
            pst.setString(18, prefEdu);
            pst.setInt(19, prefHeightStart);
            pst.setInt(20, prefHeightEnd);
            pst.setString(21, prefBuild);
            pst.setString(22, prefMari);
            pst.setString(23, prefArea);
            pst.setInt(24, prefAgeStart);
            pst.setInt(25, prefAgeEnd);
            pst.setString(26, currentPersonality);
            pst.setString(27, currentHobbies);
            pst.setString(28, currentCharac);

            pst.executeUpdate();

        } catch (Exception e) {
            System.out.println("error");
            System.out.println(e);
        }*/

        /*try {
            Class.forName("com.mysql.jdbc.Driver");
            Statement myStmt = null;
            Connection cw = DriverManager.getConnection("jdbc:mysql://localhost:3306/mmwdb?useSSL=false", "root", "");
            Connection c1 = DriverManager.getConnection("jdbc:mysql://localhost:3306/mm1db?useSSL=false", "root", "");
            Connection c3 = DriverManager.getConnection("jdbc:mysql://localhost:3306/mm3db?useSSL=false", "root", "");
            myStmt = cw.createStatement();
            myStmt1 = c1.createStatement();
            myStmt3 = c3.createStatement();
            myRsw = myStmt.executeQuery("select * from mmw");
            ResultSet myRsw = null;
            
            //System.out.println(myRsw.getString("Name"));
            //jLabel2.setText(myRsw.getString("Name"));
            while (myRsw.next()) {
                if (myRsw.getInt("ID") == id) {
                    System.out.println(myRsw.getString("Name"));
                    jLabel2.setText(myRsw.getString("Name"));
                    System.out.println(myRsw.getString("DOB"));
                    jLabel8.setText(myRsw.getString("DOB"));
                    System.out.println(myRsw.getString("Email"));
                    jLabel5.setText(myRsw.getString("Email"));
                    System.out.println(myRsw.getString("Phone"));
                    jLabel6.setText(myRsw.getString("Phone"));
                     byte[] img = myRsw.getBytes("Photo");
                    ImageIcon image = new ImageIcon(img);
                    Image im = image.getImage();
                    Image myImg = im.getScaledInstance(jLabel1.getWidth(), jLabel1.getHeight(), Image.SCALE_SMOOTH);
                    ImageIcon newImage = new ImageIcon(myImg);
                    jLabel1.setIcon(newImage);
                }
                  
            }
            
            
           Statement myStmt3 = c3.createStatement();
            ResultSet myRs3 = null;
            
            
            myRs3 = myStmt3.executeQuery("select * from mm3");
            //myRsw = myStmt.executeQuery("select * from alldata");
            while (myRs3.next()) {
                if (myRs3.getInt("ID") == id) {
                    System.out.println(myRs3.getString("Hobbies"));
                    jLabel10.setText(myRs3.getString("Hobbies"));
                    System.out.println(myRs3.getString("Charac"));
                    jLabel13.setText(myRs3.getString("Charac") + "\n" + myRs3.getString("Personality"));
                }
            }
            //System.out.println(welcomeList.get(0).name);
            //jLabel2.setText("Hiiii");
        } catch (Exception e) {
            System.out.println("error");

        }*/
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     *///algorithm
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLayeredPane1 = new javax.swing.JLayeredPane();
        jPanel3 = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setPreferredSize(new java.awt.Dimension(1284, 720));

        jPanel1.setPreferredSize(new java.awt.Dimension(1280, 720));

        jPanel2.setBackground(new java.awt.Color(51, 0, 102));
        jPanel2.setForeground(new java.awt.Color(51, 0, 102));
        jPanel2.setPreferredSize(new java.awt.Dimension(900, 720));

        jLabel1.setBackground(new java.awt.Color(255, 204, 255));
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));

        jLabel2.setFont(new java.awt.Font("Century Gothic", 0, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Name");

        jLabel3.setFont(new java.awt.Font("Century Gothic", 0, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Email:");

        jLabel4.setFont(new java.awt.Font("Century Gothic", 0, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Phone:");

        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("b");

        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("r");

        jLabel7.setFont(new java.awt.Font("Century Gothic", 0, 14)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Date Of Birth");

        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("h");

        javax.swing.GroupLayout jLayeredPane1Layout = new javax.swing.GroupLayout(jLayeredPane1);
        jLayeredPane1.setLayout(jLayeredPane1Layout);
        jLayeredPane1Layout.setHorizontalGroup(
            jLayeredPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jLayeredPane1Layout.setVerticalGroup(
            jLayeredPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        jPanel3.setBackground(new java.awt.Color(141, 253, 253));
        jPanel3.setForeground(new java.awt.Color(141, 253, 253));

        jLabel9.setFont(new java.awt.Font("Century Gothic", 1, 18)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(51, 0, 102));
        jLabel9.setText("About me");

        jLabel10.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(51, 0, 102));
        jLabel10.setText("dfdf");

        jLabel13.setFont(new java.awt.Font("Century Gothic", 1, 14)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(51, 0, 102));
        jLabel13.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);

        jLabel14.setFont(new java.awt.Font("Century Gothic", 0, 14)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(51, 0, 102));
        jLabel14.setText("Personality:");

        jLabel15.setFont(new java.awt.Font("Century Gothic", 0, 14)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(51, 0, 102));
        jLabel15.setText("Hobbies:");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel15)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 154, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 319, Short.MAX_VALUE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel14)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel13, javax.swing.GroupLayout.DEFAULT_SIZE, 381, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(72, 72, 72)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(55, 55, 55)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(134, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(61, 61, 61)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 178, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(36, 36, 36)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel7)
                            .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, 139, Short.MAX_VALUE)
                            .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addGap(34, 34, 34)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 401, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLayeredPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(55, 55, 55))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(77, 77, 77)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 205, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLayeredPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(45, 45, 45)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(36, 36, 36)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel5))
                        .addGap(54, 54, 54)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(334, Short.MAX_VALUE))
        );

        jLabel11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/matchmaking/mprofile.jpeg"))); // NOI18N

        jLabel12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/matchmaking/mprofile.jpeg"))); // NOI18N
        jLabel12.setText("jLabel12");

        jButton1.setText("View Matches");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 177, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(45, 45, 45)
                .addComponent(jButton1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 729, Short.MAX_VALUE)
                .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addGap(192, 192, 192)
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(192, Short.MAX_VALUE)))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel12, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton1)
                .addGap(377, 377, 377))
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, 1020, Short.MAX_VALUE)
                    .addContainerGap()))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 1284, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 1052, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        try {
            System.out.println("Matching....");
            Class.forName("com.mysql.jdbc.Driver");
            Connection c = DriverManager.getConnection("jdbc:mysql://localhost:3306/mmwdb?useSSL=false", "root", "");
            Statement myStmtd = c.createStatement();
            String gender = "Female";
            ResultSet myRsd = myStmtd.executeQuery("select * from alldata");
            //if(gender.equals(myRsw.getString("Gender")))
            while (myRsd.next()) {
                if (myRsd.getInt("ID") == id) {
                    currentGender=myRsd.getString("Gender");
                    currentAge = myRsd.getInt("Age");
                    currentRel = myRsd.getString("Rel");
                    System.out.println("Current Religion:"+currentRel);
                    currentOccu = myRsd.getString("Occu");
                    currentEdu = myRsd.getString("Edu");
                    currentHeight = myRsd.getInt("Height");
                    currentBuild = myRsd.getString("Phy_Build");
                    currentMari = myRsd.getString("Mari_Status");
                    currentArea = myRsd.getString("Area");

                    prefRel = myRsd.getString("P_Rel");
                    prefOccu = myRsd.getString("P_Occu");
                    prefEdu = myRsd.getString("P_Edu");
                    prefHeightStart = myRsd.getInt("Height_S");
                    prefHeightEnd = myRsd.getInt("Height_E");
                    prefBuild = myRsd.getString("P_Phy_Build");
                    prefMari = myRsd.getString("PMari");
                    prefArea = myRsd.getString("PArea");
                    prefAgeStart = myRsd.getInt("Age_S");
                    prefAgeEnd = myRsd.getInt("Age_E");

                }
            }
            
                if (gender.equals(currentGender)) {
                    ResultSet myRsFem = myStmt.executeQuery("select * from male");
                    while (myRsFem.next()) {
                        System.out.println("loop1");
                        if (prefRel.equals(myRsFem.getString("Rel")) && currentRel.equals(myRsFem.getString("P_Rel"))) {
                            System.out.println("loop2");
                            if (prefOccu.equals(myRsFem.getString("Occu")) && currentOccu.equals(myRsFem.getString("P_Occu"))) {
                                System.out.println("loop3");
                                if (prefEdu.equals(myRsFem.getString("Edu")) && currentEdu.equals(myRsFem.getString("P_Edu"))) {
                                    System.out.println("loop4");
                                    if ((myRsFem.getInt("Age") >= prefAgeStart && myRsFem.getInt("Age") <= prefAgeEnd) && (myRsFem.getInt("Age_S") <= currentAge && myRsFem.getInt("Age_E") >= currentAge)) {
                                        System.out.println("loop5");
                                        if ((myRsFem.getInt("Height") >= prefHeightStart && myRsFem.getInt("Height") <= prefHeightEnd) && (myRsFem.getInt("Height_S") <= currentHeight && myRsFem.getInt("Height_E") >= currentHeight)) {
                                            System.out.println("loop6");
                                            if (prefBuild.equals(myRsFem.getString("Phy_Build")) && currentBuild.equals(myRsFem.getString("P_Phy_Build"))) {
                                                System.out.println("loop7");
                                                if (prefMari.equals(myRsFem.getString("Mari_Status")) && currentMari.equals(myRsFem.getString("PMari"))) {
                                                    System.out.println("loop8");
                                                    if (prefArea.equals(myRsFem.getString("Area")) && currentArea.equals(myRsFem.getString("PArea"))) {
                                                        matchID[matchFound] = myRsFem.getInt("ID");
                                                        matchFound++;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                } else {
                    ResultSet myRsMale = myStmt.executeQuery("select * from female");
                    while (myRsMale.next()) {
                        System.out.println("loop1");
                        if (prefRel.equals(myRsMale.getString("Rel")) && currentRel.equals(myRsMale.getString("P_Rel"))) {
                            System.out.println("loop2");
                            if (prefOccu.equals(myRsMale.getString("Occu")) && currentOccu.equals(myRsMale.getString("P_Occu"))) {
                                System.out.println("loop3");
                                if (prefEdu.equals(myRsMale.getString("Edu")) && currentEdu.equals(myRsMale.getString("P_Edu"))) {
                                    System.out.println("loop4");
                                    if ((myRsMale.getInt("Age") >= prefAgeStart && myRsMale.getInt("Age") <= prefAgeEnd) && (myRsMale.getInt("Age_S") <= currentAge && myRsMale.getInt("Age_E") >= currentAge)) {
                                        System.out.println("loop5");
                                        if ((myRsMale.getInt("Height") >= prefHeightStart && myRsMale.getInt("Height") <= prefHeightEnd) && (myRsMale.getInt("Height_S") <= currentHeight && myRsMale.getInt("Height_E") >= currentHeight)) {
                                            System.out.println("loop6");
                                            if (prefBuild.equals(myRsMale.getString("Phy_Build")) && currentBuild.equals(myRsMale.getString("P_Phy_Build"))) {
                                                System.out.println("loop7");
                                                if (prefMari.equals(myRsMale.getString("Mari_Status")) && currentMari.equals(myRsMale.getString("PMari"))) {
                                                    System.out.println("loop8");
                                                    if (prefArea.equals(myRsMale.getString("Area")) && currentArea.equals(myRsMale.getString("PArea"))) {
                                                        matchID[matchFound] = myRsMale.getInt("ID");
                                                        matchFound++;
                                                        System.out.println("Matching....");
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                System.out.println(matchID[0]);
            
        } catch (Exception e) {
            System.out.println(e);
        }
        new Matches().setVisible(true);
        this.dispose();
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Profile.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Profile.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Profile.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Profile.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        //jLabel1.setText("HIIIII");
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Profile(id).setVisible(true);

            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JLayeredPane jLayeredPane1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    // End of variables declaration//GEN-END:variables
}
