/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package matchmaking;

import java.sql.Connection;
import java.sql.DriverManager;

/**
 *
 * @author Habibur Rahman
 */
public class dbConnection4 {
     Connection c=null;
    public static Connection cdb(){
    try{
    Class.forName("com.mysql.jdbc.Driver");
     Connection c=DriverManager.getConnection("jdbc:mysql://localhost:3306/mm4db?useSSL=false","root","");
return c;
    }
    catch(Exception e)
    {
        System.out.println("error");
        return null;
    }

    }
    
}
